$(document).ready(function(){
    clickRandomButton();
    // alert("turd")
    
});

// I want to generate a random pokedork!
function returnRandomPokemon(){
    var randomPokemon = Math.trunc(Math.random()* 151)+1
    // console.log(randomPokemon)
    return randomPokemon
}

// After generating a random pokedok, I must trieve it from the API and then create the sprite in getPokemonSprite!
function clickRandomButton(){
    $(".btn_randoPokeDORK").click(function(){
        $.get("http://pokeapi.co/api/v2/pokemon/" + returnRandomPokemon(), function(res){
            // console.log(res.name);
            // console.log(res.sprites.front_default)
            console.log(res.types[1]["type"].name)
            // At this version, the software will CRASH if the pokemon has only ONE type. So, we are disabling the second type.
            getPokemonSprite(res.sprites.front_default, res.id, res.name, res.weight, res.types[0]["type"].name);//, res.types[1]["type"].name);
        }); 
    })
};


// I want to get the sprite of the pokemon!
function getPokemonSprite(src, id, name, weight, type1){ //
    // console.log(type1);
    // var someDorkName = document.getElementsByClassName("pokeDorkName");
    // changes pokeDORK name
    $(".pokeDorkName").text(name); 
    // adds pokeDORK weight
    $(".weight").text(weight);

    // adds pokeDORK type1
    $(".typePrimary").text(type1);

    // adds pokeDORK type2
    // $(".typeSecondary").text(type2);
    // console.log($(".weight").text(weight + " POUNDS!"))
    // Adds pokeDORK img
    $("#img_pokeDORK").attr("src", src);
}
